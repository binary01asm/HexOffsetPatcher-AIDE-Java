package com.binary01.hexoffset;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.*;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.*;

public class MainActivity extends Activity {
	
	public final int REQ_CD_FP = 101;
	
	private EditText edittext1;
	private EditText edittext2;
	private EditText edittext3;
	private Button button_patch;
	private Button button_chooseFile;
	
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		//setContentView(R.layout.main);
		initialize(_savedInstanceState);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        //startService(new Intent(getApplicationContext(), FloatingWindowService.class));
        try {
            if (Settings.canDrawOverlays(this)) {
				if (FloatingWindowService.isServiceRunning()) {
						startService(new Intent(getApplicationContext(), FloatingWindowService.class));
				}
				else {
						startService(new Intent(getApplicationContext(), FloatingWindowService.class));
				}
		}
		else {
				if (!Settings.canDrawOverlays(getApplicationContext())) {
						Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
						Uri.parse("package:" + getPackageName()));
						startActivityForResult(intent, 100);
				}
				startService(new Intent(getApplicationContext(), FloatingWindowService.class));
		 }
        
            
        }
            catch(Exception e) {
             Toast.makeText(getApplication(), e.toString(), Toast.LENGTH_SHORT).show();  
                
            }
		
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			} else {
				initializeLogic();
			}
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
        startService(new Intent(getApplicationContext(), FloatingWindowService.class));
        final LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(8,8,8,8);
        
        final ScrollView scrollView = new ScrollView(this);
		final LinearLayout linear = new LinearLayout(this);
        linear.setOrientation(1);
        scrollView.addView(linear);
		edittext1 = new EditText(this);
        edittext1.setHint((new Object() {
   int t;
   public String toString() {
      byte[] buf = new byte[14];
      t = 1502695063;
      buf[0] = (byte) (t >>> 14);
      t = -610772580;
      buf[1] = (byte) (t >>> 22);
      t = 1949694582;
      buf[2] = (byte) (t >>> 24);
      t = -1919630149;
      buf[3] = (byte) (t >>> 18);
      t = -1278447088;
      buf[4] = (byte) (t >>> 8);
      t = -1993062670;
      buf[5] = (byte) (t >>> 8);
      t = -959767968;
      buf[6] = (byte) (t >>> 6);
      t = 1781930257;
      buf[7] = (byte) (t >>> 15);
      t = -1819493024;
      buf[8] = (byte) (t >>> 13);
      t = 2124473368;
      buf[9] = (byte) (t >>> 17);
      t = 817820990;
      buf[10] = (byte) (t >>> 23);
      t = 1318219536;
      buf[11] = (byte) (t >>> 21);
      t = -928299825;
      buf[12] = (byte) (t >>> 11);
      t = -1562009577;
      buf[13] = (byte) (t >>> 20);
      return new String(buf);
   }
}.toString()));
        edittext1.setShadowLayer(3,4,0,Color.GRAY);
        edittext1.setHintTextColor(0xFF000000);
        edittext1.setTextColor(0xFF000000);
        edittext1.setTextSize(15);
        linear.addView(edittext1,params);
		edittext2 = new EditText(this);
        edittext2.setHint((new Object() {
   int t;
   public String toString() {
      byte[] buf = new byte[12];
      t = 1586538406;
      buf[0] = (byte) (t >>> 7);
      t = -69704177;
      buf[1] = (byte) (t >>> 8);
      t = -681231561;
      buf[2] = (byte) (t >>> 3);
      t = 1999814993;
      buf[3] = (byte) (t >>> 20);
      t = 812802250;
      buf[4] = (byte) (t >>> 1);
      t = 1398061686;
      buf[5] = (byte) (t >>> 7);
      t = -657795554;
      buf[6] = (byte) (t >>> 13);
      t = 493011659;
      buf[7] = (byte) (t >>> 9);
      t = 1815942684;
      buf[8] = (byte) (t >>> 24);
      t = 987481253;
      buf[9] = (byte) (t >>> 23);
      t = -1822052313;
      buf[10] = (byte) (t >>> 16);
      t = 788027902;
      buf[11] = (byte) (t >>> 24);
      return new String(buf);
   }
}.toString()));
        edittext2.setShadowLayer(3,4,0,Color.GRAY);
        edittext2.setHintTextColor(0xFF000000);
        edittext2.setTextColor(0xFF000000);
        edittext2.setTextSize(15);
        linear.addView(edittext2,params);
		edittext3 = new EditText(this);
        edittext3.setHint((new Object() {
   int t;
   public String toString() {
      byte[] buf = new byte[16];
      t = 1046635082;
      buf[0] = (byte) (t >>> 4);
      t = 472363152;
      buf[1] = (byte) (t >>> 2);
      t = -1837267944;
      buf[2] = (byte) (t >>> 19);
      t = 2048760413;
      buf[3] = (byte) (t >>> 10);
      t = -1599497337;
      buf[4] = (byte) (t >>> 10);
      t = -73618062;
      buf[5] = (byte) (t >>> 19);
      t = -1353295123;
      buf[6] = (byte) (t >>> 12);
      t = 1819597858;
      buf[7] = (byte) (t >>> 16);
      t = -1254405608;
      buf[8] = (byte) (t >>> 20);
      t = 1681894867;
      buf[9] = (byte) (t >>> 2);
      t = -97226159;
      buf[10] = (byte) (t >>> 8);
      t = 1197319777;
      buf[11] = (byte) (t >>> 10);
      t = 119604956;
      buf[12] = (byte) (t >>> 1);
      t = -442738027;
      buf[13] = (byte) (t >>> 18);
      t = 1004624016;
      buf[14] = (byte) (t >>> 2);
      t = -237755143;
      buf[15] = (byte) (t >>> 8);
      return new String(buf);
   }
}.toString()));
        edittext3.setShadowLayer(3,4,0,Color.GRAY);
        edittext3.setHintTextColor(0xFF000000);
        edittext3.setTextColor(0xFF000000);
        edittext3.setTextSize(15);
        linear.addView(edittext3,params);
		button_patch = new Button(this);
        button_patch.setHint((new Object() {
   int t;
   public String toString() {
      byte[] buf = new byte[7];
      t = 2095904561;
      buf[0] = (byte) (t >>> 9);
      t = -732941617;
      buf[1] = (byte) (t >>> 16);
      t = 1816002374;
      buf[2] = (byte) (t >>> 21);
      t = 1786570773;
      buf[3] = (byte) (t >>> 9);
      t = 1983030266;
      buf[4] = (byte) (t >>> 20);
      t = -203316792;
      buf[5] = (byte) (t >>> 10);
      t = 1545564547;
      buf[6] = (byte) (t >>> 14);
      return new String(buf);
   }
}.toString()));
        button_patch.setShadowLayer(3,4,0,Color.GRAY);
        button_patch.setHintTextColor(0xFF777777);
        button_patch.setTextColor(0xFF000000);
        button_patch.setTextSize(18);
        linear.addView(button_patch,params);
		button_chooseFile = new Button(this);
        button_chooseFile.setHint((new Object() {
   int t;
   public String toString() {
      byte[] buf = new byte[12];
      t = -750926693;
      buf[0] = (byte) (t >>> 15);
      t = -1808516905;
      buf[1] = (byte) (t >>> 20);
      t = -1269291460;
      buf[2] = (byte) (t >>> 23);
      t = 443342568;
      buf[3] = (byte) (t >>> 9);
      t = 932419946;
      buf[4] = (byte) (t >>> 23);
      t = 1561447797;
      buf[5] = (byte) (t >>> 10);
      t = 1630708776;
      buf[6] = (byte) (t >>> 15);
      t = -286487527;
      buf[7] = (byte) (t >>> 9);
      t = 517153156;
      buf[8] = (byte) (t >>> 17);
      t = -1252317870;
      buf[9] = (byte) (t >>> 14);
      t = 1089610134;
      buf[10] = (byte) (t >>> 2);
      t = -1768641797;
      buf[11] = (byte) (t >>> 1);
      return new String(buf);
   }
}.toString()));
        button_chooseFile.setShadowLayer(3,4,0,Color.GRAY);
        button_chooseFile.setHintTextColor(0xFF777777);
        button_chooseFile.setTextColor(0xFF000000);
        button_chooseFile.setTextSize(18);
        linear.addView(button_chooseFile,params);
        setContentView(scrollView);
		fp.setType("*/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		button_patch.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				String filePath = edittext1.getText().toString();
				String offsetStr = edittext2.getText().toString();
				String newText = edittext3.getText().toString();
				
				// Validate inputs
				if (filePath.isEmpty() || offsetStr.isEmpty() || newText.isEmpty()) {
					    Toast.makeText(getApplicationContext(), "Please_enter_all_values.",Toast.LENGTH_SHORT).show();
					    return;
				}
				
				try {
					    long offset = Long.parseLong(offsetStr, 16); // Convert hex offset to decimal
					    RandomAccessFile file = new RandomAccessFile(filePath, "rw");
					    file.seek(offset); // Move to the specified offset
					    file.write(newText.getBytes()); // Write new data
					    file.close();
					    
					    Toast.makeText(getApplicationContext(), "File_edited_successfully.",Toast.LENGTH_SHORT).show();
				} catch (Exception e) {
					    Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		button_chooseFile.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp, REQ_CD_FP);
			}
		});
	}
	
	
	public int getName(String fileId,String res){
		  return getBaseContext().getResources().getIdentifier(fileId,res,getBaseContext().getPackageName());
	}
	private void initializeLogic() {
		
		edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFF44FF44, 0xFFFFFFFF));
		edittext2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFF44FF44, 0xFFFFFFFF));
		edittext3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFF44FF44, 0xFFFFFFFF));
		button_patch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFFFFECC));
        button_chooseFile.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFFFFECC));
        edittext1.setTypeface(Typeface.MONOSPACE);
        edittext2.setTypeface(Typeface.MONOSPACE);
        edittext3.setTypeface(Typeface.MONOSPACE);       
          edittext1.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           edittext1.requestFocus();
           InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
           imm.showSoftInput(edittext1, InputMethodManager.SHOW_IMPLICIT);
       }
   });  
   edittext2.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           edittext2.requestFocus();
           InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
           imm.showSoftInput(edittext2, InputMethodManager.SHOW_IMPLICIT);
       }
   });
   edittext3.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           edittext3.requestFocus();
           InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
           imm.showSoftInput(edittext3, InputMethodManager.SHOW_IMPLICIT);
       }
   });
         
 }
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				edittext1.setText(_filePath.get((int)(0)));
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0,0,0,"Exit");
		MenuItem menuitem1 = menu.add(Menu.NONE, 1, Menu.NONE, "HexOffset");
		menuitem1.setIcon(R.drawable.ic_icon);
		menuitem1.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		final int _id = item.getItemId();
		final String _title = (String) item.getTitle();
        if (_id == 0) {
            finish();
		}
        
		if (_id == 1) {
            
            try{
			if (!Settings.canDrawOverlays(getApplicationContext())) {
						Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
						Uri.parse("package:" + getPackageName()));
						startActivityForResult(intent, 100);
				}
				else {
						if (FloatingWindowService.isServiceRunning()) {
								stopService(new Intent(getApplicationContext(), FloatingWindowService.class));
						}
						else {
								startService(new Intent(getApplicationContext(), FloatingWindowService.class));
						}
				}
				if (FloatingWindowService.isServiceRunning()) {
					stopService(new Intent(getApplicationContext(), FloatingWindowService.class));
				}
				else {
					startService(new Intent(getApplicationContext(), FloatingWindowService.class));
				} 
            }catch(Exception e){String log = e.toString();
                Toast.makeText(getApplicationContext(),log,Toast.LENGTH_SHORT).show();
                }
            
            
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
