package com.binary01.hexoffset;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.*;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.*;

public class FloatingWindowService extends Service {
	
	private static boolean isWorking = false;  // Static flag to track service state
	private WindowManager windowManager;
	//private View floatView;
    private LinearLayout floatView;
	
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		isWorking = true;
		
		// Initialize WindowManager and inflate your custom crosshair view
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        
		/*//<!----- Layout--Inflater--Source Code ------!>
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		floatView = inflater.inflate(R.layout.floating_window_layout, null); //<!------ From Custom Layout XML File------!>
		//<!--------SourceCode---Ended--------!> */
        
		// Add the view to the window manager
        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
			    LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
         }else{
			    LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;}
      	final WindowManager.LayoutParams paramsW = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                //WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                LAYOUT_FLAG,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
                
                
                floatView = new LinearLayout(this);
                floatView.setBackgroundColor(0xFFccFFcc);
          
             final LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(8,8,8,8);
        
        final ScrollView scrollView = new ScrollView(this);
        
		final LinearLayout linear = new LinearLayout(this);
        linear.setOrientation(1);
        scrollView.addView(linear,params);
        final LinearLayout move = new LinearLayout(this);
        move.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,70));
        move.setBackgroundColor(0xff000000);
        linear.addView(move);
        final RainbowTextView rainbow = new RainbowTextView(this);
        rainbow.setText("⚙HexOffsetPatcher⚙");
        rainbow.setGravity(1);
        move.addView(rainbow,params);
		final EditText edittext1 = new EditText(this);
        edittext1.setHint((new Object() {
   int t;
   public String toString() {
      byte[] buf = new byte[14];
      t = 1502695063;
      buf[0] = (byte) (t >>> 14);
      t = -610772580;
      buf[1] = (byte) (t >>> 22);
      t = 1949694582;
      buf[2] = (byte) (t >>> 24);
      t = -1919630149;
      buf[3] = (byte) (t >>> 18);
      t = -1278447088;
      buf[4] = (byte) (t >>> 8);
      t = -1993062670;
      buf[5] = (byte) (t >>> 8);
      t = -959767968;
      buf[6] = (byte) (t >>> 6);
      t = 1781930257;
      buf[7] = (byte) (t >>> 15);
      t = -1819493024;
      buf[8] = (byte) (t >>> 13);
      t = 2124473368;
      buf[9] = (byte) (t >>> 17);
      t = 817820990;
      buf[10] = (byte) (t >>> 23);
      t = 1318219536;
      buf[11] = (byte) (t >>> 21);
      t = -928299825;
      buf[12] = (byte) (t >>> 11);
      t = -1562009577;
      buf[13] = (byte) (t >>> 20);
      return new String(buf);
   }
}.toString()));
        edittext1.setShadowLayer(3,4,0,Color.GRAY);
        edittext1.setTextSize(15);
        linear.addView(edittext1,params);
		final EditText edittext2 = new EditText(this);
        edittext2.setHint((new Object() {
   int t;
   public String toString() {
      byte[] buf = new byte[12];
      t = 1586538406;
      buf[0] = (byte) (t >>> 7);
      t = -69704177;
      buf[1] = (byte) (t >>> 8);
      t = -681231561;
      buf[2] = (byte) (t >>> 3);
      t = 1999814993;
      buf[3] = (byte) (t >>> 20);
      t = 812802250;
      buf[4] = (byte) (t >>> 1);
      t = 1398061686;
      buf[5] = (byte) (t >>> 7);
      t = -657795554;
      buf[6] = (byte) (t >>> 13);
      t = 493011659;
      buf[7] = (byte) (t >>> 9);
      t = 1815942684;
      buf[8] = (byte) (t >>> 24);
      t = 987481253;
      buf[9] = (byte) (t >>> 23);
      t = -1822052313;
      buf[10] = (byte) (t >>> 16);
      t = 788027902;
      buf[11] = (byte) (t >>> 24);
      return new String(buf);
   }
}.toString()));
        edittext2.setShadowLayer(3,4,0,Color.GRAY);
        edittext2.setTextSize(15);
        linear.addView(edittext2,params);
		final EditText edittext3 = new EditText(this);
        edittext3.setHint((new Object() {
   int t;
   public String toString() {
      byte[] buf = new byte[16];
      t = 1046635082;
      buf[0] = (byte) (t >>> 4);
      t = 472363152;
      buf[1] = (byte) (t >>> 2);
      t = -1837267944;
      buf[2] = (byte) (t >>> 19);
      t = 2048760413;
      buf[3] = (byte) (t >>> 10);
      t = -1599497337;
      buf[4] = (byte) (t >>> 10);
      t = -73618062;
      buf[5] = (byte) (t >>> 19);
      t = -1353295123;
      buf[6] = (byte) (t >>> 12);
      t = 1819597858;
      buf[7] = (byte) (t >>> 16);
      t = -1254405608;
      buf[8] = (byte) (t >>> 20);
      t = 1681894867;
      buf[9] = (byte) (t >>> 2);
      t = -97226159;
      buf[10] = (byte) (t >>> 8);
      t = 1197319777;
      buf[11] = (byte) (t >>> 10);
      t = 119604956;
      buf[12] = (byte) (t >>> 1);
      t = -442738027;
      buf[13] = (byte) (t >>> 18);
      t = 1004624016;
      buf[14] = (byte) (t >>> 2);
      t = -237755143;
      buf[15] = (byte) (t >>> 8);
      return new String(buf);
   }
}.toString()));
        edittext3.setShadowLayer(3,4,0,Color.GRAY);
        edittext3.setTextSize(15);
        linear.addView(edittext3,params);
		final Button button_patch = new Button(this);
        button_patch.setHint((new Object() {
   int t;
   public String toString() {
      byte[] buf = new byte[7];
      t = 2095904561;
      buf[0] = (byte) (t >>> 9);
      t = -732941617;
      buf[1] = (byte) (t >>> 16);
      t = 1816002374;
      buf[2] = (byte) (t >>> 21);
      t = 1786570773;
      buf[3] = (byte) (t >>> 9);
      t = 1983030266;
      buf[4] = (byte) (t >>> 20);
      t = -203316792;
      buf[5] = (byte) (t >>> 10);
      t = 1545564547;
      buf[6] = (byte) (t >>> 14);
      return new String(buf);
   }
}.toString()));
        button_patch.setShadowLayer(3,4,0,Color.GRAY);
        button_patch.setTextSize(18);
        linear.addView(button_patch,params);
		final Button button_close = new Button(this);
        button_close.setHint((new Object() {
   int t;
   public String toString() {
      byte[] buf = new byte[13];
      t = 2083796927;
      buf[0] = (byte) (t >>> 4);
      t = -1730771141;
      buf[1] = (byte) (t >>> 9);
      t = 1563739851;
      buf[2] = (byte) (t >>> 4);
      t = -1882067477;
      buf[3] = (byte) (t >>> 5);
      t = 60644761;
      buf[4] = (byte) (t >>> 19);
      t = -73977171;
      buf[5] = (byte) (t >>> 7);
      t = -1481484363;
      buf[6] = (byte) (t >>> 8);
      t = 1293602111;
      buf[7] = (byte) (t >>> 5);
      t = 1864385244;
      buf[8] = (byte) (t >>> 1);
      t = -166310474;
      buf[9] = (byte) (t >>> 12);
      t = -76488944;
      buf[10] = (byte) (t >>> 9);
      t = 916877551;
      buf[11] = (byte) (t >>> 1);
      t = -2142945652;
      buf[12] = (byte) (t >>> 7);
      return new String(buf);
   }
}.toString()));
        button_close.setShadowLayer(3,4,0,Color.GRAY);
        button_close.setTextSize(18);
        linear.addView(button_close,params);
        
        floatView.addView(scrollView,350,ViewGroup.LayoutParams.WRAP_CONTENT);
        //setContentView(scrollView);
        edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFF44FF44, 0xFFFFFFFF));
		edittext2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFF44FF44, 0xFFFFFFFF));
		edittext3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFF44FF44, 0xFFFFFFFF));
		button_patch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFFFFECC));
        button_close.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFFFFECC));
        floatView.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFF0F0F0));
        move.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFFEEEEEE));
        edittext1.setTypeface(Typeface.MONOSPACE);
        edittext2.setTypeface(Typeface.MONOSPACE);
        edittext3.setTypeface(Typeface.MONOSPACE); 
		
		
		button_patch.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				String filePath = edittext1.getText().toString();
				String offsetStr = edittext2.getText().toString();
				String newText = edittext3.getText().toString();
				
				// Validate inputs
				if (filePath.isEmpty() || offsetStr.isEmpty() || newText.isEmpty()) {
					    Toast.makeText(getApplicationContext(), "Please_enter_all_values.",Toast.LENGTH_SHORT).show();
					    return;
				}
				
				try {
					    long offset = Long.parseLong(offsetStr, 16); // Convert hex offset to decimal
					    RandomAccessFile file = new RandomAccessFile(filePath, "rw");
					    file.seek(offset); // Move to the specified offset
					    file.write(newText.getBytes()); // Write new data
					    file.close();
					    
					    Toast.makeText(getApplicationContext(), "File_edited_successfully.",Toast.LENGTH_SHORT).show();
				} catch (Exception e) {
					    Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		button_close.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
			//	startActivityForResult(new Intent(fp),(int) REQ_CD_FP);
            stopSelf();
			}
		});
        
      ///----------------------Focus Request -----------------!>
   edittext1.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           edittext1.requestFocus();
           InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
           imm.showSoftInput(edittext1, InputMethodManager.SHOW_IMPLICIT);
       }
   });  
   edittext2.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           edittext2.requestFocus();
           InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
           imm.showSoftInput(edittext2, InputMethodManager.SHOW_IMPLICIT);
       }
   });
   edittext3.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           edittext3.requestFocus();
           InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
           imm.showSoftInput(edittext3, InputMethodManager.SHOW_IMPLICIT);
       }
   });
      ///------------------------------ Focus Change ------------------------!>      
    edittext1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
       @Override
       public void onFocusChange(View v, boolean hasFocus) {
           if (hasFocus) {
               paramsW.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
               windowManager.updateViewLayout(floatView, paramsW);
           } else {
               paramsW.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
               windowManager.updateViewLayout(floatView, paramsW);
           }
       }
   });     
   edittext2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
       @Override
       public void onFocusChange(View v, boolean hasFocus) {
           if (hasFocus) {
               paramsW.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
               windowManager.updateViewLayout(floatView, paramsW);
           } else {
               paramsW.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
               windowManager.updateViewLayout(floatView, paramsW);
           }
       }
   });     
   edittext3.setOnFocusChangeListener(new View.OnFocusChangeListener() {
       @Override
       public void onFocusChange(View v, boolean hasFocus) {
           if (hasFocus) {
               paramsW.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
               windowManager.updateViewLayout(floatView, paramsW);
           } else {
               paramsW.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
               windowManager.updateViewLayout(floatView, paramsW);
           }
       }
   });     
    
             
             
		
        paramsW.gravity = 1 | 1;
        paramsW.x = 0;
        paramsW.y = 0;
		windowManager.addView(floatView, paramsW);
        
        floatView.setOnTouchListener(new View.OnTouchListener() {
            private  int initialX;
            private  int initialY;
            private  float initialTouchX;
            private  float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = paramsW.x;
                        initialY = paramsW.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        paramsW.x = initialX + (int) (event.getRawX() - initialTouchX);
                        paramsW.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatView, paramsW);
                        return true;
                }
                return true;
            }
        });
        
        move.setOnTouchListener(new View.OnTouchListener() {
            private  int initialX;
            private  int initialY;
            private  float initialTouchX;
            private  float initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = paramsW.x;
                        initialY = paramsW.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        paramsW.x = initialX + (int) (event.getRawX() - initialTouchX);
                        paramsW.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatView, paramsW);
                        return true;
                }
                return true;
            }
        });
        
        
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		isWorking = false;
		if (floatView != null) {
			windowManager.removeView(floatView);
		}
	}
	
	// Add this method to check if the service is currently running
	public static boolean isServiceRunning() {
		return isWorking;
	}
}
/*. <service
android:name=".FloatingWindowService"
android:enabled="true"
android:exported="false"/>. */
//<!--------Add_This_In_AndroidManifest.xml---------!>